
    
    
Factorial = 1
i = 1
n=int(input("enter number"))
while i<=n:
    Factorial = Factorial*i
    i = i+1
print("Factorial of" ,n , "is ", Factorial)
