# Enter the divident

divident = int(input("Enter divident"))

# Enter the divisor
divisor = int(input("Enter the divisor"))
quotient = float(divident) / divisor
print("The Quotient is" + str(quotient))
remainder = divident - divisor * quotient

# The remainder is
print("The Remainder is" + str(remainder))
