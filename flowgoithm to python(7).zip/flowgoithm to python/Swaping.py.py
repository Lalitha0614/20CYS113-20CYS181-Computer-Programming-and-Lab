
a = int(input("Enter the value of 1st number-a"))
b = int(input("Enter the value of 1st number-b"))

# we swap the numbers using some operations
a = a + b
b = a - b
a = a - b

# now the numbers are swapped
print("The new a is " + str(a))
print("the new b is " + str(b))
