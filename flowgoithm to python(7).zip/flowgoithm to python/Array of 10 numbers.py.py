# Declaring array of size 10
a = [0] * (10)

i = 0

# Getting input values for array
print("Enter the array elements")
for i in range(0, 9 + 1, 1):
    a[i] = int(input())

# Displaying the array contents
print("The array is")
for i in range(0, 9 + 1, 1):
    print("a" + "[" + str(i) + "]" + "=" + str(a[i]))
