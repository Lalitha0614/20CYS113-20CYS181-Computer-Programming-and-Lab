#include <stdio.h>
#define Reward 10
int main(void){
    double startkm;
    double endkm;
    double distance;
    double finalreward;
    printf("Enter the start km");
    scanf("%lf",&startkm);
    printf("Enter the end km");
    scanf("%lf",&endkm);
    distance=endkm-startkm;
    finalreward =distance*Reward;
    printf("The distance is %lf\n",distance);
    printf("The reward is %lf\n",finalreward);
    return 0;
    }
    
