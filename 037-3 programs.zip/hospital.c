#include <stdio.h>
int main(void){
    double quantity_kg;
    int time_mins;
    double volume_ml;
    double rate_mlperhr;
    printf("Enter quantity in kg");
    scanf("%lf", & quantity_kg);
    printf("Enter time in minutes");
    scanf("%d", & time_mins);
    volume_ml= (quantity_kg)*1000;
    rate_mlperhr= volume_ml/ (time_mins*0.0166667);
    printf("Volume in ml %lf \n" , volume_ml);
    printf("Rate in ml/hr %lf \n" , rate_mlperhr);
    return 0;
    }
    
