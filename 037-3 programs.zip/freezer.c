#include <stdio.h>
int main(void){
    int t;
    double T;
    printf("Enter the elapsed time");
    scanf("%d", &t);
    T=(4*t*t)/(2*t+2) - 20;
    printf("The time is %lf \n", T);
    return 0;
    }
